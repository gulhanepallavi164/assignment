package com.transaction.controller;


import java.util.List;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.beans.factory.annotation.Autowired;

import com.transaction.utilities.AuthenticationManager;
import org.springframework.data.jdbc.support.JdbcUtil;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transaction.entity.AccountDetails;
import com.transaction.entity.AuthRequest;
import com.transaction.entity.FundTransfer;
import com.transaction.entity.TransactionDetails;

import org.springframework.web.bind.annotation.RequestBody;
import com.transaction.repository.AccountDetailsRepository;
import com.transaction.service.AccountDetailsService;
import com.transaction.service.TransactionServices;

@RestController
public class UserController {
	
	@Autowired
	private JdbcUtil jwtUtil;
	
	@Autowired 
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private AccountDetailsService  accountDetailsService;
	
	@Autowired
	private TransactionServices transactionService;
	
	@PostMapping("/user/login")
	public AuthRequest generateToken(@RequestBody AuthRequest authRequest)throws Exception
	{
		try
		{
			 authenticationManager.authenticate(
	                    new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword())
			
			
		}
		catch(Exception ex)
		{
			throw new Exception("invalid username/password");
		}
		authRequest.setAccessToken(jwtUtil.generateToken(authRequest.getUserName()));
		
			return authRequest;
			
		}
	@GetMapping("getBalance/{AccountNo}")
	public AccountDetails getBalance(@PathVariable String AccountNo)
	{
		
		return  accountDetailsService.getBalance(AccountNo);
		
	}
	@PostMapping("/fundTransfer")
	public TransactionDetails foundTransfer(@RequestBody FundTransfer fundTransfer)
	{
		return TransactionServices.FundTransfer(fundTransfer);
	
	}
	@GetMapping("/getTransactionDetails/{AccountNo}")
	public List<TransactionDetails>getTransactionDetails(@PathVariable String AccountNo)
	
	{
		return TransactionServices.getTransactionDetails(AccountNo);
	}
	
	
}
	

	
	
	
	
	
	


