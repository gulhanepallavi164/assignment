package com.transaction.utilities;

import java.sql.Date;
import java.util.Map;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

public class JwtUtil {
	
private String secret="Transaction";
	
	public String extractUsername(String token)
	{
		return extractClaim(token,Claims::getSubject);
		
	}
	public Date extractExpiration(String token)
	{
	return extractClaim(token,Claims::getExpiration);	
	}
	
	public <T> T extractClaim(String token,Fumction<Claims,T>,claimsResolver)
	{
		final Claims claims=extraxtAllClaims(token);
		return claimsResolver.apply(claims);
		
	}
	private Claims extractAllClaims(String token)
	{
		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token)
	{
		return extractExpiration(token).before(new Date());
	}
	private String createToken(Map<String,Object> claims,String subject)
	{
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssusedAt(new(System.currentTimeMillis()))
		.setExpiration(new Date(System.currentTimeMillis()+1000*60*60*10))
		.signwith(SignatureAlogorithm.HS256,secret.compact());
		
	}
	public Boolean validateToken(String token,User user)
	{
		final String username=extractUsername(token);
		return(username.equals(user.getUsername() && !isTokenExpired(token));
	}
	public String generateToken(String userName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
	
	
	

}
