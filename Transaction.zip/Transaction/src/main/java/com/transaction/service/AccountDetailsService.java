package com.transaction.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.transaction.entity.AccountDetails;
import com.transaction.repository.AccountDetailsRepository;
@Service
public class AccountDetailsService {
	
	@Autowired
	
	private AccountDetailsRepository accountdetailsrepository;
	
	public AccountDetails getBalance(String accountNo) {
		Long AccountNoInLong =Long.parseLong(accountNo);
		
		
		System.out.print(accountdetailsrepository.findByAccountNo(AccountNoInLong));

		return accountdetailsrepository.findByAccountNo(AccountNoInLong);
	}
	
	
	

}
