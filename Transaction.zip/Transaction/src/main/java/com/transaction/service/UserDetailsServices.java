package com.transaction.service;

import org.springframework.stereotype.Service;

@Service
public class UserDetailsServices {
	
	
	
	
	

}
