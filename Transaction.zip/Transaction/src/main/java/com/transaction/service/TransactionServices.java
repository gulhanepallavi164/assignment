package com.transaction.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transaction.entity.AccountDetails;
import com.transaction.entity.FundTransfer;
import com.transaction.entity.TransactionDetails;
import com.transaction.repository.AccountDetailsRepository;
import com.transaction.repository.TransactionDetailsRepository;
@Service
public class TransactionServices {
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	

	@Autowired
	private AccountDetailsRepository accountDetailsRepository;
	

	
	public TransactionDetails fundTransfer(FundTransfer fundTransfer) {
		AccountDetails accountDetailsForAccount=accountDetailsRepository.findByAccountNo(fundTransfer.getFromAccount());
			
		AccountDetails accountDetailsForToAccount=accountDetailsRepository.findByAccountNo(fundTransfer.getToAccount());
		
		Double fromAccountsubstract=(accountDetailsForAccount.getAvailableBalance()-fundTransfer.getAmount());
		
		accountDetailsForToAccount.setAvailableBalance(fromAccountsubstract);
		accountDetailsRepository.updateFundToAccounts(fundTransfer.getFromAccount(),accountDetailsForToAccount.getAvailableBalance());
		
		TransactionDetails transactionDetails=this.save(fundTransfer.getFromAccount(),fundTransfer.getAmount(),"D",new BigInteger("9087653421"));
		
		
		this.save(fundTransfer.getToAccount(),fundTransfer.getAmount(),"C",new BigInteger("9087653421"));
		
		return transactionDetails;
	}
	
	public TransactionDetails save(Long accountNo,Double amount,String flag,BigInteger  reference_No)
	{
		AccountDetails accountDetails=accountDetailsRepository.findByAccountNo(accountNo);
		
		TransactionDetails transactionDetails=new TransactionDetails();
		
		transactionDetails.setTransactionAmount(amount);
		
		transactionDetails.setTransaction_flag(flag);
		
		transactionDetails.setReferenceNumber(reference_No);
		
		transactionDetails.setAccountDetails(accountDetails);
		
		//accountDetails.getAccountNo().add(transactionDetails);
		
		return transactionDetailsRepository.save(transactionDetails);
	}
	public List<TransactionDetails>getTransactionDetails(String AccountNo)
	{
	Long AccountNoInLong=Long.parseLong(AccountNo);
	return transactionDetailsRepository.findByAccountNo(AccountNoInLong);
	
	}
}
	
	


