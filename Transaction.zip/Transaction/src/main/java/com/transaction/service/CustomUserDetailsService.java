package com.transaction.service;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

import com.transaction.repository.UserRepository;

public class CustomUserDetailsService  {
	


}
