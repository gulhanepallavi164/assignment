package com.transaction.entity;



import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="transaction_details")

public class TransactionDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	//@Size(max=1)
	
	@Column(name="transaction_flag",length=1)
	private String transaction_flag;
	
	
	@Column(name="transaction_amount",length=12)
	private Double transactionAmount;
	
	
	@Column(name="refence_number",length=10)
	private BigInteger referenceNumber;


	   @JsonIgnore
	    @JoinColumn(name = "account_no", referencedColumnName = "account_no")
	    @ManyToOne(optional = false)
	    private AccountDetails accountDetails;
	

	public TransactionDetails() {
		
		
	}

	

	public TransactionDetails(int id, String transaction_flag, Double transactionAmount, BigInteger referenceNumber) {
		super();
		this.id = id;
		this.transaction_flag = transaction_flag;
		this.transactionAmount = transactionAmount;
		this.referenceNumber = referenceNumber;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getTransaction_flag() {
		return transaction_flag;
	}


	public void setTransaction_flag(String transaction_flag) {
		this.transaction_flag = transaction_flag;
	}


	public Double getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


	public BigInteger getReferenceNumber() {
		return referenceNumber;
	}


	public void setReferenceNumber(BigInteger referenceNumber) {
		this.referenceNumber = referenceNumber;
	}



	public void setAccountDetails(AccountDetails accountDetails) {
		// TODO Auto-generated method stub
		
	}
	


}
