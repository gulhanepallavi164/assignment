package com.transaction.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class AccountDetails {
	

	@Id
	@JsonIgnore
	 @Column(name = "account_no",length=10)
	 private Long accountNo;
	 
	
	 @Column(name="available_balance",length=12)
	 private Double availableBalance;
	 
	 
	 
	  @JsonIgnore
	    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountDetails")
		List<TransactionDetails> TransactionDetails=new ArrayList<>();
	    



	public AccountDetails() {
	
		
	}


	public AccountDetails(Long accountNo, Double availableBalance) {
		super();
		this.accountNo = accountNo;
		this.availableBalance = availableBalance;
	}


	public Long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}


	public Double getAvailableBalance() {
		return availableBalance;
	}


	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}
	 
}