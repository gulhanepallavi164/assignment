package com.transaction.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="user_details")
public class User {
	
	@Column(name="user_id", length=5)
	private int UserId;
	
	@Id
	@Column(name="account_No" ,length=10)
	private Long accountNo;
	
	@Column(name="password")
	private String password;
	
	
    @OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="account_no", referencedColumnName="account_no")
	List<TransactionDetails> TransactionDetails=new ArrayList<>();
	
//    @OneToMany(cascade=CascadeType.ALL)
//   	@JoinColumn(name="account_no", referencedColumnName="account_no")
//   	List<TransactionDetails> AccountDetails=new ArrayList<>();
//    
//    
    
 //  @OneToMany(cascade = CascadeType.ALL,mappedBy = "user_details")
  //   private List<AccountDetails> accountDetails;
	

	public User() {
		
		// TODO Auto-generated constructor stub
	}



	public User(int userId, Long accountNo, String password,
		List<com.transaction.entity.TransactionDetails> transactionDetails) {
		super();
		UserId = userId;
		this.accountNo = accountNo;
     this.password = password;
	TransactionDetails = transactionDetails;
	}



	public int getUserId() {
		return UserId;
	}



	public void setUserId(int userId) {
		UserId = userId;
	}



	public Long getAccountNo() {
		return accountNo;
	}



	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public List<TransactionDetails> getTransactionDetails() {
		return TransactionDetails;
	}



	public void setTransactionDetails(List<TransactionDetails> transactionDetails) {
		TransactionDetails = transactionDetails;
	}


	
	
	

}
