package com.transaction.repository;

import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.transaction.entity.AccountDetails;

@Repository
public interface AccountDetailsRepository extends JpaRepository<AccountDetails, Long> {

	@Modifying
	void updateFoundToAccount(Long AccountNo,Double Balance);

AccountDetails findByAccountNo(Long accountNo);

void updateFundToAccounts(Long fromAccount, Double availableBalance);
	



}
